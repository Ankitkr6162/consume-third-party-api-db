package io.spring.consume.rest.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumeRestApiDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumeRestApiDbApplication.class, args);
	}

}
